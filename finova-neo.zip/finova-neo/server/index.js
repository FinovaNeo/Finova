import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import yahooFinance from 'yahoo-finance2';
import Parser from 'rss-parser';

try { yahooFinance.suppressNotices?.(['yahooSurvey']); } catch {}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

const rss = new Parser({ timeout: 10000, headers: { 'User-Agent': 'Mozilla/5.0 FinovaNeo' } });

// ---------- helpers ----------
const cache = new Map();
async function cached(key, ttl, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < ttl) return hit.v;
  const v = await fn();
  cache.set(key, { t: Date.now(), v });
  return v;
}
const wrap = (fn) => (req, res) =>
  fn(req, res).catch((e) => {
    console.error(req.path, e.message);
    res.status(500).json({ error: e.message });
  });

// ---------- Yahoo Finance ----------
app.get('/api/quotes', wrap(async (req, res) => {
  const symbols = String(req.query.symbols || '').split(',').map((s) => s.trim()).filter(Boolean).slice(0, 60);
  if (!symbols.length) return res.json([]);
  const data = await cached('q:' + symbols.join(), 5000, () => yahooFinance.quote(symbols));
  res.json(
    (Array.isArray(data) ? data : [data]).map((q) => ({
      symbol: q.symbol,
      name: q.shortName || q.longName || q.symbol,
      price: q.regularMarketPrice,
      change: q.regularMarketChange,
      pct: q.regularMarketChangePercent,
      prevClose: q.regularMarketPreviousClose,
      open: q.regularMarketOpen,
      high: q.regularMarketDayHigh,
      low: q.regularMarketDayLow,
      volume: q.regularMarketVolume,
      mcap: q.marketCap,
      pe: q.trailingPE,
      eps: q.epsTrailingTwelveMonths,
      hi52: q.fiftyTwoWeekHigh,
      lo52: q.fiftyTwoWeekLow,
      currency: q.currency,
      type: q.quoteType,
      state: q.marketState,
    }))
  );
}));

const RANGES = {
  '1D': { d: 5, i: '5m' },
  '1W': { d: 8, i: '30m' },
  '1M': { d: 31, i: '1d' },
  '6M': { d: 183, i: '1d' },
  '1Y': { d: 365, i: '1d' },
  '5Y': { d: 1825, i: '1wk' },
};
app.get('/api/chart', wrap(async (req, res) => {
  const { symbol, range = '1M' } = req.query;
  if (!symbol) return res.status(400).json({ error: 'symbol required' });
  const r = RANGES[range] || RANGES['1M'];
  const out = await cached(`c:${symbol}:${range}`, 30000, () =>
    yahooFinance.chart(String(symbol), { period1: new Date(Date.now() - r.d * 864e5), interval: r.i })
  );
  let pts = (out.quotes || []).filter((q) => q.close != null).map((q) => ({ t: new Date(q.date).getTime(), c: q.close }));
  if (range === '1D' && pts.length) {
    const last = pts[pts.length - 1].t;
    pts = pts.filter((p) => last - p.t < 24 * 3600e3);
  }
  res.json(pts);
}));

app.get('/api/search', wrap(async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) return res.json([]);
  const r = await yahooFinance.search(q, { quotesCount: 10, newsCount: 0 });
  res.json(
    (r.quotes || [])
      .filter((x) => x.symbol && x.isYahooFinance !== false)
      .map((x) => ({ symbol: x.symbol, name: x.shortname || x.longname || x.symbol, type: x.quoteType, exch: x.exchDisp }))
  );
}));

app.get('/api/summary', wrap(async (req, res) => {
  const symbol = String(req.query.symbol || '');
  const s = await cached('s:' + symbol, 60000, () =>
    yahooFinance.quoteSummary(
      symbol,
      { modules: ['assetProfile', 'financialData', 'recommendationTrend', 'defaultKeyStatistics', 'summaryDetail'] },
      { validateResult: false }
    )
  );
  const fd = s.financialData || {};
  const rt = s.recommendationTrend?.trend?.[0] || {};
  res.json({
    about: s.assetProfile?.longBusinessSummary,
    sector: s.assetProfile?.sector,
    industry: s.assetProfile?.industry,
    website: s.assetProfile?.website,
    employees: s.assetProfile?.fullTimeEmployees,
    targetMean: fd.targetMeanPrice,
    recommendation: fd.recommendationKey,
    analysts: fd.numberOfAnalystOpinions,
    revenueGrowth: fd.revenueGrowth,
    profitMargin: fd.profitMargins,
    roe: fd.returnOnEquity,
    debtToEquity: fd.debtToEquity,
    beta: s.defaultKeyStatistics?.beta ?? s.summaryDetail?.beta,
    forwardPE: s.summaryDetail?.forwardPE ?? s.defaultKeyStatistics?.forwardPE,
    dividendYield: s.summaryDetail?.dividendYield,
    trend: { strongBuy: rt.strongBuy, buy: rt.buy, hold: rt.hold, sell: rt.sell, strongSell: rt.strongSell },
  });
}));

// ---------- News: BBC + Bloomberg ----------
const FEEDS = {
  bbc: [{ source: 'BBC', url: 'https://feeds.bbci.co.uk/news/business/rss.xml' }],
  bloomberg: [
    { source: 'Bloomberg', url: 'https://feeds.bloomberg.com/markets/news.rss' },
    { source: 'Bloomberg', url: 'https://feeds.bloomberg.com/technology/news.rss' },
  ],
};
FEEDS.all = [...FEEDS.bloomberg, ...FEEDS.bbc];

app.get('/api/news', wrap(async (req, res) => {
  const key = FEEDS[req.query.source] ? req.query.source : 'all';
  const items = await cached('n:' + key, 5 * 60e3, async () => {
    const results = await Promise.allSettled(
      FEEDS[key].map(async (f) => {
        const feed = await rss.parseURL(f.url);
        return feed.items.slice(0, 15).map((i) => ({
          title: i.title,
          link: i.link,
          date: i.isoDate || i.pubDate,
          source: f.source,
          summary: (i.contentSnippet || '').slice(0, 220),
        }));
      })
    );
    return results
      .filter((r) => r.status === 'fulfilled')
      .flatMap((r) => r.value)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  });
  res.json(items);
}));

// ---------- Finova Intelligence (LLM) ----------
const LLM = () => ({
  key: process.env.LLM_API_KEY,
  base: (process.env.LLM_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, ''),
  model: process.env.LLM_MODEL || 'gpt-4o-mini',
  vision: process.env.LLM_VISION_MODEL || process.env.LLM_MODEL || 'gpt-4o-mini',
});

async function llm(body) {
  const c = LLM();
  const r = await fetch(`${c.base}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${c.key}` },
    body: JSON.stringify(body),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error?.message || 'LLM error');
  return j.choices[0].message.content;
}

const SYSTEM = `You are "Finova Intelligence", the AI financial assistant inside the Finova Neo app (Finance · Economics · Intelligence).
Users are mostly university students and beginners with no finance background, aged 18-35, many in Malaysia/Asia.
Rules:
- Reply in the same language the user writes in (Chinese by default). Keep it clear, structured and beginner friendly.
- Explain jargon in one line. Use the live market data given in CONTEXT when relevant; never invent prices.
- For stock/crypto analysis give: what it is, key numbers, bull case, bear case, risks, and what to watch. Be balanced.
- You are educational only, not a licensed adviser. Do not promise returns. End investment-related answers with a one-line reminder that this is not financial advice.`;

app.post('/api/chat', wrap(async (req, res) => {
  const c = LLM();
  if (!c.key) {
    return res.json({ reply: 'Finova Intelligence 尚未配置：请在服务器 .env 中设置 LLM_API_KEY 后重启。' });
  }
  const { messages = [], symbol, context } = req.body;
  let ctx = '';
  if (symbol) {
    try {
      const [q] = await Promise.all([yahooFinance.quote(symbol)]);
      ctx += `Live quote ${symbol}: price ${q.regularMarketPrice} ${q.currency}, change ${q.regularMarketChangePercent?.toFixed(2)}%, PE ${q.trailingPE}, 52w ${q.fiftyTwoWeekLow}-${q.fiftyTwoWeekHigh}, mcap ${q.marketCap}.\n`;
      const s = await yahooFinance.quoteSummary(symbol, { modules: ['financialData', 'recommendationTrend'] }, { validateResult: false });
      const fd = s.financialData || {};
      ctx += `Analyst: ${fd.recommendationKey}, target ${fd.targetMeanPrice}, rev growth ${fd.revenueGrowth}, margin ${fd.profitMargins}.\n`;
    } catch {}
  }
  if (context) ctx += String(context).slice(0, 3000);
  const reply = await llm({
    model: c.model,
    temperature: 0.4,
    messages: [{ role: 'system', content: SYSTEM + (ctx ? `\n\nCONTEXT:\n${ctx}` : '') }, ...messages.slice(-16)],
  });
  res.json({ reply });
}));

// photo receipt -> structured bookkeeping entry
app.post('/api/receipt', wrap(async (req, res) => {
  const c = LLM();
  if (!c.key) return res.status(400).json({ error: '未配置 LLM_API_KEY，无法识别收据，请手动记账。' });
  const { image, categories = [] } = req.body;
  if (!image) return res.status(400).json({ error: 'image required' });
  const text = await llm({
    model: c.vision,
    temperature: 0,
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: `Read this receipt/payment screenshot. Return ONLY JSON: {"merchant":string,"amount":number,"currency":string,"date":"YYYY-MM-DD" or null,"time":"HH:MM" or null,"category":one of ${JSON.stringify(categories)},"payment":"cash"|"card"|"bank"|"ewallet"|null}`,
          },
          { type: 'image_url', image_url: { url: image } },
        ],
      },
    ],
  });
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) throw new Error('无法解析收据');
  res.json(JSON.parse(m[0]));
}));

// ---------- static client ----------
const dist = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (req, res) => res.sendFile(path.join(dist, 'index.html')));
}

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => console.log(`Finova Neo running on :${PORT}`));
