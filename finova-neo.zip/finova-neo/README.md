# Finova Neo — Finance · Economics · Intelligence

Robinhood 风格的理财 + 投资 App（React + Node）。一套代码可发布为网站 / PWA / iOS / Android。

## 功能（对应你的笔记）

| 模块 | 说明 |
|---|---|
| 首页 | 重大财经新闻头条轮播（Bloomberg + BBC RSS）、**Learn more with AI**、三个入口卡片（Funds / Academy / AI）带动画演示、全球指数条 |
| 资金概览 Funds Overview（免费） | **AI 自动记账**：拍照 → 识别商家/金额/分类/日期 → 选支付方式；**手动记账**：金额 → Income/Expenses/Transfer → 分类（可手动添加）→ 日期时间 → 支付方式；保存后同步更新现金流、资产负债、预算。底部 8 个页面：Book / Budget / Cash Flow / Charts / Account / Asset Allocation / P&L / Portfolio Risk & Health。**Slide 2**：透明金猪 + 各分类金币条，支出时金币掉落动画 |
| 投资 Invest | Yahoo Finance 实时行情：股票、加密货币、ETF、马来西亚 Bursa；搜索、自选、1D/1W/1M/6M/1Y/5Y 走势图、分析师评级、**模拟**买卖 |
| 投资组合（参考 Delta） | 持仓、盈亏、配置饼图、年化波动率、最大回撤、夏普、集中度、健康分 |
| 市场研究 | 全球指数、板块热力图、宏观（利率/美元/黄金/原油/VIX）、涨跌榜、AI 市场简报 |
| Finova Academy | 8 个模块（储蓄/股票/ETF/债券&REIT/财报/组合/宏观/行为金融）+ 测验 + 进度，Pro 内容可锁定 |
| Finova Intelligence（AI） | 财务分析师 / 资产配置师 / 投资顾问 / 行动计划；自动带入标的实时数据与你的持仓 |

品牌命名按你的笔记：Finova Neo / Finova Intelligence / Finova Academy / Finova Invest。

## 本地运行

```bash
cp .env.example .env        # 填 LLM_API_KEY
npm install
npm --prefix client install
npm run dev                 # API :8787，前端 :5173
```

## 部署为网站（可直接上线）

```bash
npm run build && npm start  # 后端同时托管 client/dist
# 或 Docker：docker build -t finova-neo . && docker run -p 8787:8787 --env-file .env finova-neo
```
可部署到 Render / Railway / Fly.io / 任意 VPS，配 HTTPS 和域名（如 finovaneo.com）。手机浏览器打开即可「添加到主屏幕」（PWA）。

## 上架 App Store / Google Play（Capacitor）

```bash
cd client
npm i @capacitor/core @capacitor/cli @capacitor/ios @capacitor/android
VITE_API_BASE=https://api.你的域名.com npm run build
npx cap add ios && npx cap add android
npx cap sync && npx cap open ios   # 或 android
```
原生 App 内没有同源后端，所以必须设置 `VITE_API_BASE` 指向已部署的后端。

## 重要说明

1. **AI 聊天**：不能复制 Moomoo 或 ChatGPT 的原始（专有）代码。这里用 OpenAI 兼容接口（`server/index.js` 的 `/api/chat`）实现同类体验：系统提示词 + 实时行情注入。换模型只改 `.env`。
2. **交易是模拟的**：真实股票/加密货币交易需要券商/交易所牌照（你笔记里“后续④⑤⑥”也写了需牌照）。上线真实交易请接入持牌券商 API（如 Alpaca、IBKR）或交易所 API，并完成 KYC/合规；在此之前请保持“模拟交易”标识。
3. **Yahoo Finance 数据**：`yahoo-finance2` 使用 Yahoo 非官方接口，适合原型与小规模；商业上线前建议换正式授权数据源（Polygon、Twelve Data、Finnhub 等），只需改 `server/index.js` 的 `/api/quotes`、`/api/chart`。
4. **新闻**：只展示标题、摘要并链接到 BBC / Bloomberg 原文，不转载全文。Bloomberg RSS 偶尔限制访问，失败时自动只显示 BBC。
5. **上架合规**：App 内需放隐私政策、免责声明（已内置“不构成投资建议”）；涉及订阅（Pro）需用 Apple/Google 内购；马来西亚境内提供投资建议需遵守 SC（证监会）规定。
6. 数据存在手机本地（localStorage）。要多设备同步，需加用户登录 + 数据库（如 Supabase/Firebase）。

## 目录

```
server/index.js          Express：行情、图表、搜索、新闻、AI、收据识别
client/src/pages/        Home Funds Invest Stock Portfolio Research Academy Chat
client/src/lib/          api、store（记账+模拟交易）、portfolio（风险指标）
```
