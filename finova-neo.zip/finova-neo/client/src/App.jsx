import React from 'react';
import { NavLink, Route, Routes, Navigate } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Funds from './pages/Funds.jsx';
import Invest from './pages/Invest.jsx';
import Stock from './pages/Stock.jsx';
import Portfolio from './pages/Portfolio.jsx';
import Research from './pages/Research.jsx';
import Academy from './pages/Academy.jsx';
import Chat from './pages/Chat.jsx';

const TABS = [
  ['/', '⌂', 'Home'],
  ['/invest', '📈', 'Invest'],
  ['/funds', '🐷', 'Funds'],
  ['/academy', '🎓', 'Academy'],
  ['/ai', '✦', 'AI'],
];

export default function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/funds" element={<Funds />} />
        <Route path="/invest" element={<Invest />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/research" element={<Research />} />
        <Route path="/s/:symbol" element={<Stock />} />
        <Route path="/academy" element={<Academy />} />
        <Route path="/ai" element={<Chat />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <nav className="nav">
        {TABS.map(([to, ic, label]) => (
          <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
            <span className="ic">{ic}</span>
            {label}
          </NavLink>
        ))}
      </nav>
    </>
  );
}
