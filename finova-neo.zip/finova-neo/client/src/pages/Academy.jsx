import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useStore, markLearned, setPro } from '../lib/store.js';
import { Modal } from '../components.jsx';

const MODULES = [
  { id: 'emergency', level: '理财基础', title: '储蓄和紧急预备金', pro: false,
    lessons: ['紧急预备金是为失业、疾病、突发维修准备的钱，建议存 3–6 个月的必要开支，放在随时能取的账户。', '先付自己：发薪当天先转 10–20% 到储蓄，再花剩下的。给储蓄设目标和期限更容易坚持。'],
    quiz: { q: '紧急预备金最适合放在哪里？', o: ['高波动的成长股', '随时可取、低风险的账户', '加密货币'], a: 1 } },
  { id: 'stocks', level: '入门投资', title: '股票投资', pro: false,
    lessons: ['股票代表公司的一小部分所有权。价格由买卖双方的供需决定，短期波动大，长期与公司盈利相关。', '入门看三件事：公司赚钱吗（营收/利润）、估值贵不贵（市盈率 P/E）、风险在哪（行业、负债）。'],
    quiz: { q: '市盈率 P/E 衡量的是？', o: ['股价相对每股盈利的倍数', '公司员工人数', '每日成交量'], a: 0 } },
  { id: 'etf', level: '入门投资', title: 'ETF 与指数投资', pro: false,
    lessons: ['ETF 像一篮子股票，可在交易所像股票一样买卖。买一只标普500 ETF，就等于同时持有 500 家公司。', '指数投资费用低、分散度高。定期定额（每月固定金额）可以降低择时风险。'],
    quiz: { q: 'ETF 的主要优势是？', o: ['保证盈利', '一次买入一篮子资产，分散风险', '没有任何费用'], a: 1 } },
  { id: 'bond', level: '进阶投资', title: '债券与 REIT', pro: true,
    lessons: ['债券是你借钱给政府/公司，对方付利息并到期还本。利率上升时，已发行债券价格通常下跌。', 'REIT 是投资房地产的基金，持有租金收入型物业并把大部分收益分红，但对利率敏感。'],
    quiz: { q: '市场利率上升，已发行债券价格通常？', o: ['上升', '下降', '不变'], a: 1 } },
  { id: 'fin', level: '进阶投资', title: '财报分析', pro: true,
    lessons: ['三张表：利润表（赚多少）、资产负债表（有多少、欠多少）、现金流量表（现金进出）。利润为正但经营现金流长期为负要警惕。', '关注营收增速、毛利率、净利率、负债/权益比、自由现金流，并与同行比较。'],
    quiz: { q: '哪张表反映现金进出？', o: ['利润表', '资产负债表', '现金流量表'], a: 2 } },
  { id: 'portfolio', level: '进阶投资', title: '投资组合管理', pro: true,
    lessons: ['资产配置决定大部分长期结果。不同资产（股/债/现金/黄金）相关性低，组合起来可降低波动。', '定期再平衡：当某类资产涨太多偏离目标比例，就卖出一部分补回其他资产。'],
    quiz: { q: '再平衡的目的？', o: ['把组合拉回目标风险比例', '追涨最强资产', '全部换成现金'], a: 0 } },
  { id: 'macro', level: '全球金融', title: '宏观经济', pro: true,
    lessons: ['央行利率、通胀、GDP、就业数据会影响所有资产。加息通常压制成长股估值，利好银行存款收益。', '汇率影响跨境投资回报：美元升值时，以马币计价的美股收益会被放大（反之亦然）。'],
    quiz: { q: '通胀过高时央行常见做法？', o: ['加息', '降息', '印更多钞票'], a: 0 } },
  { id: 'behavior', level: '进阶投资', title: '行为金融', pro: true,
    lessons: ['常见偏误：过度自信、损失厌恶（亏损比盈利更痛）、羊群效应、锚定效应。它们让人追涨杀跌。', '对策：写投资计划、设定仓位上限、定期定额、给自己冷静期，不凭情绪下单。'],
    quiz: { q: '损失厌恶指的是？', o: ['喜欢承担风险', '亏损带来的痛苦大于同等盈利的快乐', '只买低价股'], a: 1 } },
];

export default function Academy() {
  const s = useStore();
  const [open, setOpen] = useState(null);
  const done = Object.keys(s.learned).length;
  const levels = [...new Set(MODULES.map((m) => m.level))];

  return (
    <div className="page">
      <div className="row between"><div className="logo">FINOVA <b>Academy</b></div><span className="tag pro">Pro</span></div>
      <p className="mut small">轻松学金融知识，从零基础到会看财报、会做组合。</p>
      <div className="card">
        <div className="row between small"><span>学习进度</span><b>{done}/{MODULES.length}</b></div>
        <div className="bar" style={{ marginTop: 8 }}><i style={{ width: `${(done / MODULES.length) * 100}%` }} /></div>
      </div>

      {levels.map((lv) => (
        <div key={lv}>
          <h2>{lv}</h2>
          {MODULES.filter((m) => m.level === lv).map((m) => {
            const locked = m.pro && !s.pro;
            return (
              <div key={m.id} className="li" style={{ cursor: 'pointer' }} onClick={() => setOpen(m)}>
                <span style={{ fontSize: 22 }}>{s.learned[m.id] ? '✅' : locked ? '🔒' : '📘'}</span>
                <div className="grow"><div className="bold">{m.title}</div><div className="mut tiny">{m.lessons.length} 课 + 测验</div></div>
                {m.pro && <span className="tag pro">Pro</span>}
              </div>
            );
          })}
        </div>
      ))}

      <div className="card" style={{ marginTop: 18 }}>
        <b>更多内容</b>
        <p className="small mut">想要某个主题的定制讲解（全球金融、财经新闻分析）？问 Finova AI。</p>
        <Link to={`/ai?q=${encodeURIComponent('请用通俗中文教我：如何分析一则财经新闻并判断它对市场的影响？')}`} className="btn sm">✦ 问 AI</Link>
      </div>
      {!s.pro && <button className="btn ghost full" style={{ marginTop: 12 }} onClick={() => setPro(true)}>解锁 Pro（演示开关，上线后接入订阅支付）</button>}

      {open && <Lesson m={open} locked={open.pro && !s.pro} onClose={() => setOpen(null)} />}
    </div>
  );
}

function Lesson({ m, locked, onClose }) {
  const [pick, setPick] = useState(null);
  if (locked)
    return (
      <Modal onClose={onClose}>
        <h2 style={{ marginTop: 0 }}>🔒 {m.title}</h2>
        <p className="mut">这是 Pro 内容。订阅后即可解锁全部进阶课程。</p>
        <button className="btn full" onClick={() => { setPro(true); onClose(); }}>解锁 Pro（演示）</button>
      </Modal>
    );
  const ok = pick === m.quiz.a;
  return (
    <Modal onClose={onClose}>
      <h2 style={{ marginTop: 0 }}>{m.title}</h2>
      {m.lessons.map((l, i) => <div key={i} className="lesson"><b className="up">第 {i + 1} 课 </b>{l}</div>)}
      <h3 style={{ margin: '14px 0 6px' }}>小测验：{m.quiz.q}</h3>
      {m.quiz.o.map((o, i) => (
        <button key={i} className={`opt ${pick != null ? (i === m.quiz.a ? 'ok' : i === pick ? 'bad' : '') : ''}`} onClick={() => { setPick(i); if (i === m.quiz.a) markLearned(m.id); }}>{o}</button>
      ))}
      {pick != null && <p className={ok ? 'up' : 'dn'}>{ok ? '答对了！已完成本节 ✅' : '再想想，选正确答案可完成本节。'}</p>}
      <button className="btn ghost full" onClick={onClose}>关闭</button>
    </Modal>
  );
}
