import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getQuotes, search } from '../lib/api.js';
import { useAsync } from '../lib/utils.js';
import { useStore } from '../lib/store.js';
import { QuoteRow, InvestTabs, Err, Disclaimer } from '../components.jsx';

const LISTS = {
  Watchlist: null,
  Stocks: ['AAPL', 'MSFT', 'NVDA', 'GOOGL', 'AMZN', 'META', 'TSLA', 'AVGO', 'JPM', 'V'],
  Crypto: ['BTC-USD', 'ETH-USD', 'SOL-USD', 'XRP-USD', 'BNB-USD', 'DOGE-USD', 'ADA-USD'],
  ETF: ['SPY', 'QQQ', 'VTI', 'VOO', 'GLD', 'TLT', 'ARKK'],
  Bursa: ['1155.KL', '1295.KL', '1023.KL', '5347.KL', '5183.KL', '6888.KL'],
};

export default function Invest() {
  const s = useStore();
  const [tab, setTab] = useState('Stocks');
  const [q, setQ] = useState('');
  const [res, setRes] = useState([]);
  const syms = tab === 'Watchlist' ? s.watch : LISTS[tab];
  const [quotes, err] = useAsync(() => (syms.length ? getQuotes(syms) : Promise.resolve([])), [syms.join()], 10000);

  useEffect(() => {
    if (!q.trim()) return setRes([]);
    const t = setTimeout(() => search(q).then(setRes).catch(() => setRes([])), 300);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <div className="page">
      <InvestTabs />
      <input className="input" placeholder="搜索股票 / 加密货币 / ETF（如 AAPL、BTC、Maybank）" value={q} onChange={(e) => setQ(e.target.value)} />
      {res.length > 0 && (
        <div className="card" style={{ marginTop: 8 }}>
          {res.map((r) => (
            <Link key={r.symbol} to={`/s/${encodeURIComponent(r.symbol)}`} className="li" onClick={() => setQ('')}>
              <div className="grow"><div className="sym">{r.symbol}</div><div className="mut small">{r.name}</div></div>
              <span className="mut tiny">{r.exch}</span>
            </Link>
          ))}
        </div>
      )}

      <div className="scroll" style={{ margin: '14px 0 4px' }}>
        {Object.keys(LISTS).map((k) => (
          <button key={k} className={`chip ${tab === k ? 'on' : ''}`} onClick={() => setTab(k)}>{k}</button>
        ))}
      </div>

      <Err e={err} />
      {!quotes && !err && <div className="skeleton" style={{ height: 260, marginTop: 10 }} />}
      {quotes?.map((x) => <QuoteRow key={x.symbol} q={x} />)}
      {tab === 'Watchlist' && !s.watch.length && <p className="mut">进入任一股票页点 ☆ 加入自选。</p>}
      <Disclaimer />
    </div>
  );
}
