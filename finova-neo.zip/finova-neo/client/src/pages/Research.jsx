import React from 'react';
import { Link } from 'react-router-dom';
import { getQuotes } from '../lib/api.js';
import { useAsync, fmt, pct, cls } from '../lib/utils.js';
import { InvestTabs, Err, Disclaimer } from '../components.jsx';

const INDICES = ['^GSPC', '^IXIC', '^DJI', '^KLSE', '^HSI', '^N225', '^FTSE'];
const MACRO = [['^TNX', '美国10年期国债收益率'], ['DX-Y.NYB', '美元指数'], ['GC=F', '黄金'], ['CL=F', '原油'], ['MYR=X', 'USD/MYR'], ['^VIX', '恐慌指数 VIX']];
const SECTORS = [['XLK', '科技'], ['XLF', '金融'], ['XLE', '能源'], ['XLV', '医疗'], ['XLY', '可选消费'], ['XLP', '必需消费'], ['XLI', '工业'], ['XLU', '公用事业'], ['XLRE', '房地产'], ['XLB', '材料'], ['XLC', '通信']];
const UNIVERSE = ['AAPL', 'MSFT', 'NVDA', 'GOOGL', 'AMZN', 'META', 'TSLA', 'AVGO', 'JPM', 'V', 'NFLX', 'AMD', 'COST', 'DIS', 'BABA', 'TSM'];

const heat = (p) => {
  const a = Math.min(Math.abs(p || 0) / 3, 1);
  return p >= 0 ? `rgba(0,200,5,${0.15 + a * 0.6})` : `rgba(255,80,0,${0.15 + a * 0.6})`;
};

export default function Research() {
  const [idx, e1] = useAsync(() => getQuotes(INDICES), [], 30000);
  const [mac] = useAsync(() => getQuotes(MACRO.map((m) => m[0])), [], 60000);
  const [sec] = useAsync(() => getQuotes(SECTORS.map((m) => m[0])), [], 60000);
  const [uni] = useAsync(() => getQuotes(UNIVERSE), [], 60000);
  const movers = uni ? [...uni].sort((a, b) => b.pct - a.pct) : [];
  const brief = '请用中文写一份今日全球市场简报：美股、亚洲市场、利率与美元、大宗商品、加密货币，以及需要关注的风险。';

  return (
    <div className="page">
      <InvestTabs />
      <Err e={e1} />
      <h2 style={{ marginTop: 4 }}>全球指数</h2>
      {idx?.map((q) => (
        <Link key={q.symbol} to={`/s/${encodeURIComponent(q.symbol)}`} className="li">
          <div className="grow"><div className="sym">{q.name}</div><div className="mut tiny">{q.symbol}</div></div>
          <div className="right"><div className="bold">{fmt(q.price)}</div><div className={`small ${cls(q.pct)}`}>{pct(q.pct)}</div></div>
        </Link>
      ))}

      <h2>板块热力图（美股 SPDR ETF）</h2>
      <div className="heat">
        {SECTORS.map(([s, n]) => {
          const q = sec?.find((x) => x.symbol === s);
          return (
            <Link key={s} to={`/s/${s}`} style={{ background: heat(q?.pct), borderRadius: 10, padding: 10, fontSize: 12 }}>
              <div className="bold">{n}</div><div className="tiny mut">{s}</div><div className="bold">{pct(q?.pct)}</div>
            </Link>
          );
        })}
      </div>

      <h2>宏观与大宗商品</h2>
      <div className="card">
        {MACRO.map(([s, n]) => {
          const q = mac?.find((x) => x.symbol === s);
          return (
            <div key={s} className="row between small" style={{ padding: '6px 0' }}>
              <span>{n}</span><span>{fmt(q?.price)} <span className={cls(q?.pct)}>{pct(q?.pct)}</span></span>
            </div>
          );
        })}
      </div>

      <h2>热门股票涨跌榜</h2>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        {[['领涨', movers.slice(0, 5)], ['领跌', movers.slice(-5).reverse()]].map(([t, list]) => (
          <div key={t} className="card grow">
            <div className="mut small" style={{ marginBottom: 4 }}>{t}</div>
            {list.map((q) => (
              <Link key={q.symbol} to={`/s/${q.symbol}`} className="row between small" style={{ padding: '5px 0' }}>
                <b>{q.symbol}</b><span className={cls(q.pct)}>{pct(q.pct)}</span>
              </Link>
            ))}
          </div>
        ))}
      </div>

      <Link to={`/ai?q=${encodeURIComponent(brief)}`} className="btn full" style={{ display: 'block', textAlign: 'center', marginTop: 18 }}>✦ 生成 AI 市场简报</Link>
      <Disclaimer />
    </div>
  );
}
