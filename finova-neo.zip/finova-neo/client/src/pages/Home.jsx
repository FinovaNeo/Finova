import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getNews, getQuotes } from '../lib/api.js';
import { useAsync, fmt, pct, cls, ago } from '../lib/utils.js';
import { Err } from '../components.jsx';

const SRC = [['all', '全部'], ['bloomberg', 'Bloomberg'], ['bbc', 'BBC']];

export default function Home() {
  const nav = useNavigate();
  const [src, setSrc] = useState('all');
  const [i, setI] = useState(0);
  const [news, err] = useAsync(() => getNews(src), [src], 5 * 60e3);
  const [idx] = useAsync(() => getQuotes(['^GSPC', '^IXIC', '^DJI', '^KLSE', 'BTC-USD']), [], 20000);

  useEffect(() => {
    const t = setInterval(() => setI((x) => x + 1), 7000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => setI(0), [src]);

  const list = (news || []).slice(0, 8);
  const item = list.length ? list[i % list.length] : null;

  return (
    <div className="page">
      <div className="row between">
        <div className="logo">FINOVA <b>NEO</b></div>
        <span className="mut tiny">Finance · Economics · Intelligence</span>
      </div>

      <div className="scroll" style={{ marginTop: 12 }}>
        {(idx || []).map((q) => (
          <Link key={q.symbol} to={`/s/${encodeURIComponent(q.symbol)}`} className="card" style={{ minWidth: 112, padding: 10 }}>
            <div className="tiny mut">{q.name?.slice(0, 14)}</div>
            <div className="bold small">{fmt(q.price)}</div>
            <div className={`tiny ${cls(q.pct)}`}>{pct(q.pct)}</div>
          </Link>
        ))}
      </div>

      <div className="row" style={{ margin: '14px 0 8px' }}>
        {SRC.map(([k, l]) => (
          <button key={k} className={`chip ${src === k ? 'on' : ''}`} onClick={() => setSrc(k)}>{l}</button>
        ))}
      </div>

      <div className="headline" key={item?.link || 'x'}>
        <Err e={err} />
        {item ? (
          <>
            <div className="tiny mut">{item.source} · {ago(item.date)}</div>
            <h3 style={{ fontSize: 19, margin: '8px 0', lineHeight: 1.3 }}>{item.title}</h3>
            <div className="mut small">{item.summary}</div>
            <div className="row" style={{ marginTop: 12 }}>
              <button className="btn sm" onClick={() => nav(`/ai?q=${encodeURIComponent('请用简单中文解读这条财经新闻，并说明对普通投资者/学生的影响：' + item.title)}`)}>
                Learn more ✦ With AI
              </button>
              <a className="btn sm ghost" href={item.link} target="_blank" rel="noreferrer">阅读原文</a>
            </div>
          </>
        ) : !err ? <div className="skeleton" style={{ height: 110 }} /> : null}
      </div>
      <div className="row" style={{ justifyContent: 'center', gap: 5, marginTop: 8 }}>
        {list.map((_, k) => (
          <i key={k} style={{ width: 6, height: 6, borderRadius: 3, background: k === i % list.length ? '#00c805' : '#333' }} />
        ))}
      </div>

      <div className="entry" onClick={() => nav('/funds')}>
        <div className="row between"><h3>资金概览 Funds Overview</h3><span className="tag">免费</span></div>
        <div className="demo coins">
          {[20, 70, 120, 170, 220].map((l, k) => <span key={k} className="coin" style={{ left: l, animationDelay: k * 0.45 + 's' }}>$</span>)}
          <span className="mut tiny">日常记账 · 预算 · 现金流</span>
        </div>
        <span className="up small bold">View more →</span>
      </div>

      <div className="entry" onClick={() => nav('/academy')}>
        <div className="row between"><h3>金融教育 FINOVA Academy</h3><span className="tag pro">部分收费</span></div>
        <div className="demo bars">{[0, 0.3, 0.6, 0.9, 1.2, 1.5].map((d, k) => <i key={k} style={{ animationDelay: d + 's' }} />)}</div>
        <span className="up small bold">View more →</span>
      </div>

      <div className="entry" onClick={() => nav('/ai')}>
        <div className="row between"><h3>AI 财务顾问 AI Financial Consultant</h3><span className="tag pro">收费</span></div>
        <div className="demo typing"><span /><span /><span /></div>
        <span className="up small bold">View more →</span>
      </div>

      <div className="entry" onClick={() => nav('/invest')}>
        <div className="row between"><h3>投资 Invest</h3><span className="tag">模拟交易</span></div>
        <div className="mut small" style={{ marginTop: 6 }}>股票 · 加密货币 · 走势图 · 投资组合 · 市场研究</div>
        <div className="up small bold" style={{ marginTop: 8 }}>View more →</div>
      </div>
    </div>
  );
}
