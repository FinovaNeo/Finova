import React from 'react';
import { Link } from 'react-router-dom';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { usePortfolio } from '../lib/portfolio.js';
import { useStore } from '../lib/store.js';
import { fmt, money, pct, cls } from '../lib/utils.js';
import { InvestTabs, Disclaimer } from '../components.jsx';

export const COLORS = ['#00c805', '#4da3ff', '#f5c542', '#b48cff', '#ff8a5c', '#34d3c8', '#ff6fa8', '#9aa4ad'];

export function RiskCard({ risk }) {
  if (!risk) return <div className="card mut small">持仓少于 20 个交易日数据或尚未持仓，暂无法计算风险指标。</div>;
  const color = risk.score >= 70 ? '#00c805' : risk.score >= 45 ? '#f5c542' : '#ff5000';
  return (
    <div className="card">
      <div className="row">
        <div className="score" style={{ border: `6px solid ${color}`, color }}>{risk.score}</div>
        <div className="grow small col" style={{ gap: 4 }}>
          <div className="row between"><span className="mut">年化波动率</span><b>{fmt(risk.vol)}%</b></div>
          <div className="row between"><span className="mut">最大回撤(6M)</span><b className="dn">{fmt(risk.mdd)}%</b></div>
          <div className="row between"><span className="mut">夏普比率</span><b>{fmt(risk.sharpe)}</b></div>
          <div className="row between"><span className="mut">最大单一持仓</span><b>{fmt(risk.top, 0)}%</b></div>
        </div>
      </div>
      <p className="tiny mut" style={{ marginBottom: 0 }}>健康分综合波动率、集中度与风险调整收益（基于近6个月数据，仅供参考）。</p>
    </div>
  );
}

export default function Portfolio() {
  const p = usePortfolio();
  const s = useStore();
  const pie = [...p.rows.map((r) => ({ name: r.sym, value: r.value })), { name: 'Cash', value: p.cash }].filter((x) => x.value > 0);

  return (
    <div className="page">
      <InvestTabs />
      <div className="mut small">总资产 (模拟 USD)</div>
      <h1>{money(p.total)}</h1>
      <div className={`small ${cls(p.day)}`}>今日 {money(p.day)} · 总盈亏 {money(p.pl)} ({pct(p.plPct)})</div>

      <div className="row" style={{ margin: '14px 0' }}>
        <div className="card grow"><div className="mut tiny">持仓市值</div><b>{money(p.invested)}</b></div>
        <div className="card grow"><div className="mut tiny">购买力</div><b>{money(p.cash)}</b></div>
      </div>

      {pie.length > 0 && (
        <div className="card row">
          <div style={{ width: 130, height: 130 }}>
            <ResponsiveContainer><PieChart><Pie data={pie} dataKey="value" innerRadius={38} outerRadius={62} stroke="none">
              {pie.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Pie></PieChart></ResponsiveContainer>
          </div>
          <div className="grow small col" style={{ gap: 4 }}>
            {pie.map((x, i) => (
              <div key={x.name} className="row between"><span><i style={{ color: COLORS[i % COLORS.length] }}>●</i> {x.name.replace('-USD', '')}</span><span>{fmt((x.value / p.total) * 100, 1)}%</span></div>
            ))}
          </div>
        </div>
      )}

      <h2>持仓</h2>
      {!p.rows.length && <p className="mut small">还没有持仓。去 <Link to="/invest" className="up">Markets</Link> 买入第一只模拟股票吧。</p>}
      {p.rows.map((r) => (
        <Link key={r.sym} to={`/s/${encodeURIComponent(r.sym)}`} className="li">
          <div className="grow"><div className="sym">{r.sym.replace('-USD', '')}</div><div className="mut small">{fmt(r.qty, 4)} × {fmt(r.price)}</div></div>
          <div className="right"><div className="bold">{money(r.value)}</div><div className={`small ${cls(r.pl)}`}>{money(r.pl)} ({pct(r.plPct)})</div></div>
        </Link>
      ))}

      <h2>风险与健康度</h2>
      <RiskCard risk={p.risk} />
      {p.rows.length > 0 && (
        <Link className="btn ghost full" style={{ display: 'block', textAlign: 'center', marginTop: 12 }}
          to={`/ai?q=${encodeURIComponent('请分析我的模拟投资组合：分散度、风险、可改进之处')}&ctx=${encodeURIComponent(p.rows.map((r) => `${r.sym}: ${fmt(r.qty, 4)}股, 市值${fmt(r.value)}, 盈亏${fmt(r.plPct)}%`).join('; '))}`}>
          ✦ AI 分析我的投资组合
        </Link>
      )}

      <h2>交易记录</h2>
      {!s.orders.length && <p className="mut small">暂无订单</p>}
      {s.orders.slice(0, 20).map((o) => (
        <div key={o.id} className="li small">
          <span className={o.side === 'buy' ? 'up' : 'dn'} style={{ width: 36 }}>{o.side === 'buy' ? '买入' : '卖出'}</span>
          <span className="grow">{o.symbol} × {fmt(o.qty, 4)}</span>
          <span className="mut">@{fmt(o.price)}</span>
        </div>
      ))}
      <Disclaimer />
    </div>
  );
}
