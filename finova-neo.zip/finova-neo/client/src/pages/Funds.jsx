import React, { useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { useStore, addTx, deleteTx, setBudget, setAccount, addAccount, EXP_CATS, INC_CATS } from '../lib/store.js';
import { usePortfolio } from '../lib/portfolio.js';
import { readReceipt } from '../lib/api.js';
import { fmt, nowLocal } from '../lib/utils.js';
import { Modal, Toast } from '../components.jsx';
import { COLORS, RiskCard } from './Portfolio.jsx';

const VIEWS = [
  ['book', '📖', 'Book'], ['budget', '🧮', 'Budget'], ['cash', '💸', 'Cash Flow'], ['charts', '📊', 'Charts'],
  ['account', '🏦', 'Account'], ['asset', '🥧', 'Asset Alloc.'], ['pl', '📈', 'P&L'], ['risk', '🛡️', 'Risk & Health'],
];

const ym = (d) => d.slice(0, 7);

// ---------- pig with coin-drop animation ----------
function Pig({ ratio, dropKey }) {
  const coins = Math.max(2, Math.round(ratio * 22));
  return (
    <div className="pig-wrap">
      {dropKey > 0 && <span key={dropKey} className="coin-fall">$</span>}
      <svg viewBox="0 0 240 190" width="260" height="190">
        <defs>
          <linearGradient id="glass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fff" stopOpacity=".28" /><stop offset="1" stopColor="#9ad" stopOpacity=".08" /></linearGradient>
          <radialGradient id="g" cx=".35" cy=".3"><stop offset="0" stopColor="#ffe58a" /><stop offset="1" stopColor="#d9a21b" /></radialGradient>
        </defs>
        <ellipse cx="120" cy="178" rx="78" ry="7" fill="#000" opacity=".5" />
        {Array.from({ length: coins }).map((_, i) => (
          <circle key={i} cx={62 + ((i * 37) % 112)} cy={150 - Math.floor(i / 6) * 13 - ((i * 7) % 5)} r="11" fill="url(#g)" stroke="#a87b10" strokeWidth=".8" />
        ))}
        <path d="M58 70 Q58 40 90 36 L150 36 Q190 38 196 74 Q208 100 190 140 Q184 168 160 168 L152 168 L150 150 L96 150 L92 168 L70 168 Q52 160 56 132 Q40 104 58 70Z" fill="url(#glass)" stroke="#bfe3f7" strokeWidth="2" />
        <path d="M92 40 L84 16 L112 34Z M150 36 L166 14 L176 44Z" fill="url(#glass)" stroke="#bfe3f7" strokeWidth="2" />
        <ellipse cx="196" cy="96" rx="12" ry="16" fill="url(#glass)" stroke="#bfe3f7" strokeWidth="2" />
        <circle cx="160" cy="70" r="3.5" fill="#cde" />
        <rect x="108" y="30" width="38" height="5" rx="2.5" fill="#bfe3f7" />
      </svg>
    </div>
  );
}

function CoinBar({ spent, budget }) {
  const over = budget > 0 && spent > budget;
  const n = budget > 0 ? Math.min(24, Math.ceil((spent / budget) * 14)) : spent > 0 ? 6 : 0;
  return (
    <div className={`coinbar ${over ? 'over' : ''}`}>
      {Array.from({ length: n }).map((_, i) => <span key={i} className="coin" style={{ animationDelay: i * 25 + 'ms' }}>$</span>)}
    </div>
  );
}

// ---------- add entry (AI photo / manual) ----------
function AddEntry({ s, mode, onClose, onSaved }) {
  const [f, setF] = useState({ amount: '', type: 'expense', category: EXP_CATS[0], custom: '', date: nowLocal(), payment: 'bank', to: 'cash', merchant: '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [step, setStep] = useState(mode === 'ai' ? 'photo' : 'form');
  const file = useRef();
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const cats = f.type === 'income' ? INC_CATS : EXP_CATS;

  const onPhoto = (e) => {
    const fl = e.target.files?.[0];
    if (!fl) return;
    setBusy(true); setErr('');
    const img = new Image();
    img.onload = async () => {
      const sc = Math.min(1, 1100 / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = img.width * sc; c.height = img.height * sc;
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      try {
        const r = await readReceipt(c.toDataURL('image/jpeg', 0.8), [...EXP_CATS, 'Other']);
        const map = { cash: 'cash', card: 'card', bank: 'bank', ewallet: 'ewallet' };
        setF((x) => ({
          ...x, type: 'expense', merchant: r.merchant || '', amount: r.amount ?? '',
          category: EXP_CATS.includes(r.category) ? r.category : 'Other',
          custom: EXP_CATS.includes(r.category) ? '' : r.category && r.category !== 'Other' ? r.category : '',
          date: r.date ? `${r.date}T${r.time || '12:00'}` : x.date, payment: map[r.payment] || x.payment,
        }));
        setStep('form');
      } catch (ex) { setErr(ex.message); }
      setBusy(false);
    };
    img.src = URL.createObjectURL(fl);
  };

  const save = () => {
    if (!(+f.amount > 0)) return setErr('请输入金额');
    const category = f.type === 'transfer' ? 'Transfer' : f.category === 'More…' || f.category === 'Other' ? f.custom.trim() || 'Other' : f.category;
    const before = { ...s };
    const t = addTx({ type: f.type, amount: f.amount, category, date: f.date.slice(0, 10), time: f.date.slice(11), payment: f.payment, to: f.to, merchant: f.merchant, ai: mode === 'ai' });
    onSaved(t, before);
  };

  if (step === 'photo')
    return (
      <Modal onClose={onClose}>
        <h2 style={{ marginTop: 0 }}>AI 自动记账 · 拍照记账</h2>
        <p className="mut small">拍下小票或支付截图，AI 会读取商家、金额、分类、日期时间，你再选择支付方式即可。</p>
        <input ref={file} type="file" accept="image/*" capture="environment" hidden onChange={onPhoto} />
        <button className="btn full" disabled={busy} onClick={() => file.current.click()}>{busy ? '识别中…' : '📷 拍照 / 选择图片'}</button>
        {err && <div className="err">{err}</div>}
        <button className="btn ghost full" style={{ marginTop: 10 }} onClick={() => setStep('form')}>改为手动输入</button>
      </Modal>
    );

  return (
    <Modal onClose={onClose}>
      <h2 style={{ marginTop: 0 }}>{mode === 'ai' ? 'AI 识别结果' : '手动记账'}</h2>
      {f.merchant && <div className="mut small" style={{ marginBottom: 6 }}>商家：{f.merchant}</div>}
      <div className="col" style={{ gap: 12 }}>
        <div><div className="mut tiny">金额 Amount ({s.cur})</div><input className="input" type="number" inputMode="decimal" value={f.amount} onChange={(e) => set('amount', e.target.value)} autoFocus /></div>
        <div className="row">
          {['income', 'expense', 'transfer'].map((t) => (
            <button key={t} className={`chip grow ${f.type === t ? 'on' : ''}`} onClick={() => setF((x) => ({ ...x, type: t, category: t === 'income' ? INC_CATS[0] : EXP_CATS[0] }))}>{{ income: 'Income', expense: 'Expenses', transfer: 'Transfer' }[t]}</button>
          ))}
        </div>
        {f.type !== 'transfer' && (
          <div>
            <div className="mut tiny">{f.type === 'income' ? 'Income Category' : 'Expenses Category'}</div>
            <div className="row wrap" style={{ gap: 6, marginTop: 4 }}>
              {[...cats, 'More…'].map((c) => <button key={c} className={`chip ${f.category === c || (c === 'More…' && f.category === 'Other') ? 'on' : ''}`} onClick={() => set('category', c)}>{c}</button>)}
            </div>
            {(f.category === 'More…' || f.category === 'Other') && <input className="input" style={{ marginTop: 8 }} placeholder="手动添加分类" value={f.custom} onChange={(e) => set('custom', e.target.value)} />}
          </div>
        )}
        <div><div className="mut tiny">日期与时间 Date & Time</div><input className="input" type="datetime-local" value={f.date} onChange={(e) => set('date', e.target.value)} /></div>
        <div className="row">
          <div className="grow"><div className="mut tiny">{f.type === 'transfer' ? 'From' : 'Payment Option'}</div>
            <select className="input" value={f.payment} onChange={(e) => set('payment', e.target.value)}>{s.accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></div>
          {f.type === 'transfer' && <div className="grow"><div className="mut tiny">To</div>
            <select className="input" value={f.to} onChange={(e) => set('to', e.target.value)}>{s.accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></div>}
        </div>
        {err && <div className="err">{err}</div>}
        <button className="btn full" onClick={save}>保存</button>
      </div>
    </Modal>
  );
}

// ---------- main page ----------
export default function Funds() {
  const s = useStore();
  const p = usePortfolio();
  const [view, setView] = useState('budget');
  const [add, setAdd] = useState(null);
  const [toast, setToast] = useState('');
  const [drop, setDrop] = useState(0);
  const month = new Date().toISOString().slice(0, 7);

  const m = useMemo(() => {
    const mt = s.txs.filter((t) => ym(t.date) === month);
    const spent = {};
    let income = 0, expense = 0;
    mt.forEach((t) => {
      if (t.type === 'expense') { spent[t.category] = (spent[t.category] || 0) + t.amount; expense += t.amount; }
      if (t.type === 'income') income += t.amount;
    });
    return { spent, income, expense };
  }, [s.txs, month]);
  const totalBudget = Object.values(s.budgets).reduce((a, b) => a + b, 0);
  const assets = s.accounts.filter((a) => a.type === 'asset').reduce((a, b) => a + b.balance, 0);
  const liab = s.accounts.filter((a) => a.type === 'liability').reduce((a, b) => a + b.balance, 0);
  const netWorth = assets + liab; // paper-trading account is excluded from real net worth

  const onSaved = (t, before) => {
    setAdd(null);
    const cats = t.type === 'expense' ? t.category : null;
    const left = cats ? (s.budgets[cats] ?? 0) - ((m.spent[cats] || 0) + t.amount) : null;
    setToast(
      `✅ 已记录 ${s.cur}${fmt(t.amount)}\n现金流：${t.type === 'income' ? '+' : t.type === 'expense' ? '-' : '↔'}${fmt(t.amount)}` +
      `｜资产负债已更新` + (left != null ? `｜${cats} 预算剩余 ${fmt(left)}` : '')
    );
    if (t.type === 'expense') setDrop((d) => d + 1);
  };

  // last 6 months cash flow
  const flow = useMemo(() => {
    const out = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
      const k = d.toISOString().slice(0, 7);
      const tx = s.txs.filter((t) => ym(t.date) === k);
      out.push({ m: k.slice(5), income: tx.filter((t) => t.type === 'income').reduce((a, b) => a + b.amount, 0), expense: tx.filter((t) => t.type === 'expense').reduce((a, b) => a + b.amount, 0) });
    }
    return out;
  }, [s.txs]);

  // financial health
  const health = useMemo(() => {
    const savingsRate = m.income > 0 ? (m.income - m.expense) / m.income : 0;
    const monthlyCost = Math.max(m.expense, totalBudget * 0.6, 1);
    const emergencyMonths = (s.accounts.filter((a) => a.type === 'asset' && a.id !== 'ewallet').reduce((a, b) => a + b.balance, 0)) / monthlyCost;
    const debtRatio = assets > 0 ? Math.abs(liab) / assets : liab < 0 ? 1 : 0;
    const budgetOk = totalBudget > 0 ? Math.max(0, 1 - Math.max(0, m.expense - totalBudget) / totalBudget) : 0.5;
    const score = Math.round(Math.max(0, Math.min(100, Math.min(savingsRate, 0.3) / 0.3 * 30 + Math.min(emergencyMonths, 6) / 6 * 30 + (1 - Math.min(debtRatio, 1)) * 20 + budgetOk * 20)));
    return { savingsRate, emergencyMonths, debtRatio, budgetOk, score };
  }, [m, s.accounts, totalBudget, assets, liab]);

  const cats = Object.keys(s.budgets);
  const pieData = Object.entries(m.spent).map(([name, value]) => ({ name, value }));
  const assetPie = [
    ...s.accounts.filter((a) => a.type === 'asset' && a.balance > 0).map((a) => ({ name: a.name, value: a.balance })),
  ];

  return (
    <div className="page">
      <Toast msg={toast} onDone={() => setToast('')} />
      <div className="row between"><h2 style={{ margin: 0 }}>资金概览 <span className="mut small">Funds Overview</span></h2><span className="tag">免费</span></div>

      <div className="row" style={{ margin: '14px 0' }}>
        <button className="btn grow" onClick={() => setAdd('ai')}>📷 AI 自动记账</button>
        <button className="btn ghost grow" onClick={() => setAdd('manual')}>✍️ 手动记账</button>
      </div>

      <div className="iconbar">
        {VIEWS.map(([k, ic, l]) => <button key={k} className={view === k ? 'on' : ''} onClick={() => setView(k)}><span className="ic">{ic}</span>{l}</button>)}
      </div>

      {view === 'budget' && (
        <>
          <div className="row between" style={{ marginTop: 14 }}>
            <div className="mut small">Transparent Golden Pig<br /><span className="tiny">支出时金币掉落</span></div>
            <div className="right"><div className="mut small">{month} Budget</div><div className="mut tiny">Overall Budget</div>
              <b style={{ fontSize: 20 }}>{s.cur}{fmt(m.expense, 0)} <span className="mut">/ {s.cur}{fmt(totalBudget, 0)}</span></b></div>
          </div>
          <Pig ratio={totalBudget ? Math.max(0, 1 - m.expense / totalBudget) : 0.5} dropKey={drop} />
          {cats.map((c) => (
            <div key={c} className="li" style={{ alignItems: 'flex-start' }}>
              <div style={{ width: 108 }}>
                <div className="small bold">{c}</div>
                <input className="mut tiny" style={{ background: 'transparent', border: 0, width: 90, outline: 'none' }} type="number" value={s.budgets[c]} onChange={(e) => setBudget(c, e.target.value)} title="预算" />
              </div>
              <CoinBar spent={m.spent[c] || 0} budget={s.budgets[c]} />
              <div className={`right small ${s.budgets[c] && (m.spent[c] || 0) > s.budgets[c] ? 'dn' : ''}`} style={{ minWidth: 70 }}>{s.cur}{fmt(m.spent[c] || 0, 0)}</div>
            </div>
          ))}
          <p className="tiny mut">金币条 = 已花费 / 预算。超支会变红。点预算数字可直接修改。</p>
        </>
      )}

      {view === 'book' && (
        <div style={{ marginTop: 14 }}>
          {!s.txs.length && <p className="mut">还没有记录，点上方按钮开始记账。</p>}
          {s.txs.slice(0, 80).map((t) => (
            <div key={t.id} className="li">
              <span style={{ fontSize: 20 }}>{t.type === 'income' ? '💰' : t.type === 'transfer' ? '🔁' : '🧾'}</span>
              <div className="grow"><div className="small bold">{t.merchant || t.category}{t.ai && ' ✦'}</div><div className="mut tiny">{t.category} · {t.date} {t.time} · {s.accounts.find((a) => a.id === t.payment)?.name}</div></div>
              <div className={`right bold ${t.type === 'income' ? 'up' : t.type === 'expense' ? 'dn' : ''}`}>{t.type === 'income' ? '+' : t.type === 'expense' ? '-' : ''}{fmt(t.amount)}</div>
              <button className="chip" onClick={() => deleteTx(t.id)}>✕</button>
            </div>
          ))}
        </div>
      )}

      {view === 'cash' && (
        <div style={{ marginTop: 14 }}>
          <div className="row"><div className="card grow"><div className="mut tiny">本月收入</div><b className="up">{s.cur}{fmt(m.income)}</b></div>
            <div className="card grow"><div className="mut tiny">本月支出</div><b className="dn">{s.cur}{fmt(m.expense)}</b></div>
            <div className="card grow"><div className="mut tiny">净现金流</div><b>{s.cur}{fmt(m.income - m.expense)}</b></div></div>
          <h2>近 6 个月</h2>
          <div style={{ height: 220 }}><ResponsiveContainer><BarChart data={flow}><XAxis dataKey="m" stroke="#666" /><Tooltip contentStyle={{ background: '#111', border: '1px solid #333' }} />
            <Bar dataKey="income" fill="#00c805" radius={[4, 4, 0, 0]} /><Bar dataKey="expense" fill="#ff5000" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div>
        </div>
      )}

      {view === 'charts' && (
        <div style={{ marginTop: 14 }}>
          <h3>本月支出分类 (Income & Expenses)</h3>
          {pieData.length ? (
            <div className="card row">
              <div style={{ width: 150, height: 150 }}><ResponsiveContainer><PieChart><Pie data={pieData} dataKey="value" innerRadius={42} outerRadius={70} stroke="none">{pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie></PieChart></ResponsiveContainer></div>
              <div className="grow small col" style={{ gap: 4 }}>{pieData.map((d, i) => <div key={d.name} className="row between"><span><i style={{ color: COLORS[i % COLORS.length] }}>●</i> {d.name}</span><span>{fmt(d.value, 0)}</span></div>)}</div>
            </div>
          ) : <p className="mut small">本月暂无支出。</p>}
          <h3 style={{ marginTop: 16 }}>收支对比</h3>
          <div style={{ height: 200 }}><ResponsiveContainer><BarChart data={flow}><XAxis dataKey="m" stroke="#666" /><Tooltip contentStyle={{ background: '#111', border: '1px solid #333' }} /><Bar dataKey="income" fill="#00c805" /><Bar dataKey="expense" fill="#ff5000" /></BarChart></ResponsiveContainer></div>
        </div>
      )}

      {view === 'account' && <Accounts s={s} />}

      {view === 'asset' && (
        <div style={{ marginTop: 14 }}>
          <div className="row"><div className="card grow"><div className="mut tiny">资产 Asset</div><b className="up">{s.cur}{fmt(assets)}</b></div>
            <div className="card grow"><div className="mut tiny">负债 Liability</div><b className="dn">{s.cur}{fmt(Math.abs(liab))}</b></div>
            <div className="card grow"><div className="mut tiny">净资产</div><b>{s.cur}{fmt(netWorth)}</b></div></div>
          <h2>资产配置 Asset Allocation</h2>
          {assetPie.length ? (
            <div className="card row">
              <div style={{ width: 150, height: 150 }}><ResponsiveContainer><PieChart><Pie data={assetPie} dataKey="value" innerRadius={42} outerRadius={70} stroke="none">{assetPie.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie></PieChart></ResponsiveContainer></div>
              <div className="grow small col" style={{ gap: 4 }}>{assetPie.map((d, i) => <div key={d.name} className="row between"><span><i style={{ color: COLORS[i % COLORS.length] }}>●</i> {d.name}</span><span>{fmt((d.value / assets) * 100, 0)}%</span></div>)}</div>
            </div>
          ) : <p className="mut small">到 Account 页添加你的账户与余额。</p>}
          <p className="tiny mut">模拟交易账户不计入真实净资产。投资表现见 P&L 页。</p>
        </div>
      )}

      {view === 'pl' && (
        <div style={{ marginTop: 14 }}>
          <h3>投资表现 Performance (模拟)</h3>
          {!p.rows.length ? <p className="mut small">暂无持仓。<Link to="/invest" className="up">去投资</Link></p> : (
            <table><thead><tr><th>标的</th><th>市值</th><th>盈亏</th><th>%</th></tr></thead><tbody>
              {p.rows.map((r) => <tr key={r.sym}><td>{r.sym.replace('-USD', '')}</td><td>{fmt(r.value)}</td><td className={r.pl >= 0 ? 'up' : 'dn'}>{fmt(r.pl)}</td><td className={r.pl >= 0 ? 'up' : 'dn'}>{fmt(r.plPct)}%</td></tr>)}
              <tr><td><b>合计</b></td><td><b>{fmt(p.invested)}</b></td><td className={p.pl >= 0 ? 'up' : 'dn'}><b>{fmt(p.pl)}</b></td><td className={p.pl >= 0 ? 'up' : 'dn'}><b>{fmt(p.plPct)}%</b></td></tr>
            </tbody></table>
          )}
          <h3 style={{ marginTop: 18 }}>本月收支盈亏</h3>
          <div className="card"><div className="row between"><span>收入 − 支出</span><b className={m.income - m.expense >= 0 ? 'up' : 'dn'}>{s.cur}{fmt(m.income - m.expense)}</b></div></div>
        </div>
      )}

      {view === 'risk' && (
        <div style={{ marginTop: 14 }}>
          <h3>财务健康评分</h3>
          <div className="card">
            <div className="row">
              <div className="score" style={{ border: `6px solid ${health.score >= 70 ? '#00c805' : health.score >= 45 ? '#f5c542' : '#ff5000'}` }}>{health.score}</div>
              <div className="grow small col" style={{ gap: 5 }}>
                <div className="row between"><span className="mut">储蓄率</span><b>{fmt(health.savingsRate * 100, 0)}%</b></div>
                <div className="row between"><span className="mut">紧急备用金</span><b>{fmt(health.emergencyMonths, 1)} 个月</b></div>
                <div className="row between"><span className="mut">负债/资产</span><b>{fmt(health.debtRatio * 100, 0)}%</b></div>
                <div className="row between"><span className="mut">预算执行</span><b>{fmt(health.budgetOk * 100, 0)}%</b></div>
              </div>
            </div>
          </div>
          <h3 style={{ margin: '18px 0 8px' }}>投资组合风险 Portfolio Risk</h3>
          <RiskCard risk={p.risk} />
          <Link to={`/ai?q=${encodeURIComponent(`我的财务健康评分${health.score}/100，储蓄率${fmt(health.savingsRate * 100, 0)}%，紧急备用金${fmt(health.emergencyMonths, 1)}个月，负债占资产${fmt(health.debtRatio * 100, 0)}%。请给我具体的改善建议。`)}`} className="btn full" style={{ display: 'block', textAlign: 'center', marginTop: 14 }}>✦ AI 财务顾问改善建议</Link>
        </div>
      )}

      {add && <AddEntry s={s} mode={add} onClose={() => setAdd(null)} onSaved={onSaved} />}
    </div>
  );
}

function Accounts({ s }) {
  const [name, setName] = useState('');
  const [type, setType] = useState('asset');
  const [bal, setBal] = useState('');
  return (
    <div style={{ marginTop: 14 }}>
      {s.accounts.map((a) => (
        <div key={a.id} className="li">
          <div className="grow"><div className="bold small">{a.name}</div><span className={`tag ${a.type === 'liability' ? 'pro' : ''}`}>{a.type === 'asset' ? '资产' : '负债'}</span></div>
          <input className="input" style={{ width: 120, textAlign: 'right' }} type="number" value={a.balance} onChange={(e) => setAccount(a.id, { balance: +e.target.value })} />
        </div>
      ))}
      <h3 style={{ margin: '16px 0 6px' }}>添加账户</h3>
      <div className="row"><input className="input" placeholder="名称" value={name} onChange={(e) => setName(e.target.value)} />
        <select className="input" style={{ width: 100 }} value={type} onChange={(e) => setType(e.target.value)}><option value="asset">资产</option><option value="liability">负债</option></select></div>
      <div className="row" style={{ marginTop: 8 }}><input className="input" type="number" placeholder="余额（负债填负数）" value={bal} onChange={(e) => setBal(e.target.value)} />
        <button className="btn" onClick={() => { if (name) { addAccount(name, type, bal); setName(''); setBal(''); } }}>添加</button></div>
    </div>
  );
}
