import React, { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { getChart, getQuotes, getSummary } from '../lib/api.js';
import { useAsync, fmt, pct, cls, big, curSym } from '../lib/utils.js';
import { useStore, trade, toggleWatch } from '../lib/store.js';
import { PriceChart, Modal, Toast, Err, Disclaimer } from '../components.jsx';

const RANGES = ['1D', '1W', '1M', '6M', '1Y', '5Y'];

export default function Stock() {
  const symbol = decodeURIComponent(useParams().symbol);
  const nav = useNavigate();
  const s = useStore();
  const [range, setRange] = useState('1D');
  const [hover, setHover] = useState(null);
  const [side, setSide] = useState(null);
  const [toast, setToast] = useState('');

  const [qs, err] = useAsync(() => getQuotes([symbol]), [symbol], 8000);
  const [chart] = useAsync(() => getChart(symbol, range), [symbol, range], range === '1D' ? 30000 : 0);
  const [sum] = useAsync(() => getSummary(symbol).catch(() => ({})), [symbol]);
  const q = qs?.[0];
  const c = curSym(q?.currency);
  const holding = s.holdings[symbol];

  const first = chart?.[0]?.c;
  const last = chart?.[chart.length - 1]?.c;
  const shown = hover?.c ?? q?.price ?? last;
  const rangeChg = first && shown ? shown - first : q?.change;
  const rangePct = first && shown ? (rangeChg / first) * 100 : q?.pct;
  const up = (rangeChg ?? 0) >= 0;

  return (
    <div className="page">
      <Toast msg={toast} onDone={() => setToast('')} />
      <div className="row between">
        <button className="chip" onClick={() => nav(-1)}>← 返回</button>
        <button className="chip" onClick={() => toggleWatch(symbol)}>{s.watch.includes(symbol) ? '★ 已自选' : '☆ 自选'}</button>
      </div>
      <Err e={err} />
      <h2 style={{ marginBottom: 0 }}>{q?.name || symbol}</h2>
      <div className="mut small">{symbol} · {q?.state === 'REGULAR' ? '交易中' : q?.state || ''}</div>
      <div className="big-price">{c}{fmt(shown)}</div>
      <div className={cls(rangeChg)}>{rangeChg >= 0 ? '▲' : '▼'} {c}{fmt(Math.abs(rangeChg))} ({pct(rangePct)}) <span className="mut small">{range}</span></div>

      <PriceChart data={chart} up={up} onHover={setHover} />
      <div className="row between" style={{ margin: '4px 0 14px' }}>
        {RANGES.map((r) => (
          <button key={r} className={`chip ${range === r ? 'on' : ''}`} onClick={() => setRange(r)}>{r}</button>
        ))}
      </div>

      {holding && (
        <div className="card" style={{ marginBottom: 12 }}>
          <div className="row between"><span className="mut small">我的持仓</span><b>{fmt(holding.qty, 4)} 股/枚</b></div>
          <div className="row between small"><span className="mut">均价</span><span>{c}{fmt(holding.avg)}</span></div>
          <div className="row between small"><span className="mut">浮动盈亏</span>
            <span className={cls(q?.price - holding.avg)}>{c}{fmt((q?.price - holding.avg) * holding.qty)} ({pct(((q?.price - holding.avg) / holding.avg) * 100)})</span></div>
        </div>
      )}

      <div className="row">
        <button className="btn grow" onClick={() => setSide('buy')}>买入 Buy</button>
        <button className="btn dn grow" disabled={!holding} onClick={() => setSide('sell')}>卖出 Sell</button>
      </div>

      <h2>关键数据</h2>
      <div className="card">
        {[
          ['开盘', fmt(q?.open)], ['最高', fmt(q?.high)], ['最低', fmt(q?.low)], ['昨收', fmt(q?.prevClose)],
          ['成交量', big(q?.volume)], ['市值', big(q?.mcap)], ['市盈率 P/E', fmt(q?.pe)], ['每股盈利 EPS', fmt(q?.eps)],
          ['52周最高', fmt(q?.hi52)], ['52周最低', fmt(q?.lo52)],
        ].map(([k, v]) => (
          <div key={k} className="row between small" style={{ padding: '5px 0' }}><span className="mut">{k}</span><span>{v}</span></div>
        ))}
      </div>

      {sum && (sum.recommendation || sum.targetMean) && (
        <>
          <h2>分析师观点</h2>
          <div className="card small">
            <div className="row between"><span className="mut">综合评级</span><b style={{ textTransform: 'uppercase' }}>{sum.recommendation || '—'}</b></div>
            <div className="row between"><span className="mut">目标价均值</span><span>{c}{fmt(sum.targetMean)} ({sum.analysts || 0} 位分析师)</span></div>
            {sum.trend && (
              <div className="row" style={{ marginTop: 8, gap: 3 }}>
                {[['strongBuy', '#00c805'], ['buy', '#6fe36f'], ['hold', '#888'], ['sell', '#ff8a5c'], ['strongSell', '#ff5000']].map(([k, col]) => (
                  <div key={k} style={{ flex: Math.max(sum.trend[k] || 0, 0.2), background: col, color: '#000', textAlign: 'center', borderRadius: 4, padding: 3, fontSize: 11 }}>{sum.trend[k] || 0}</div>
                ))}
              </div>
            )}
            <div className="row between" style={{ marginTop: 8 }}><span className="mut">营收增长</span><span>{sum.revenueGrowth != null ? pct(sum.revenueGrowth * 100) : '—'}</span></div>
            <div className="row between"><span className="mut">净利率</span><span>{sum.profitMargin != null ? fmt(sum.profitMargin * 100) + '%' : '—'}</span></div>
            <div className="row between"><span className="mut">Beta</span><span>{fmt(sum.beta)}</span></div>
          </div>
        </>
      )}
      {sum?.about && (
        <>
          <h2>关于</h2>
          <p className="small mut" style={{ lineHeight: 1.6 }}>{sum.about.slice(0, 420)}…</p>
          <div className="tiny mut">{sum.sector} · {sum.industry}</div>
        </>
      )}

      <Link to={`/ai?symbol=${encodeURIComponent(symbol)}&q=${encodeURIComponent('请分析 ' + symbol + '：公司/资产概况、关键数据、看多与看空理由、主要风险')}`} className="btn ghost full" style={{ display: 'block', textAlign: 'center', marginTop: 16 }}>
        ✦ 让 Finova AI 分析 {symbol}
      </Link>
      <Disclaimer />

      {side && <TradeSheet side={side} symbol={symbol} q={q} holding={holding} cash={s.cash} onClose={() => setSide(null)} onDone={(m) => { setToast(m); setSide(null); }} />}
    </div>
  );
}

function TradeSheet({ side, symbol, q, holding, cash, onClose, onDone }) {
  const [qty, setQty] = useState('');
  const [msg, setMsg] = useState('');
  const price = q?.price || 0;
  const isCrypto = q?.type === 'CRYPTOCURRENCY';
  const est = (+qty || 0) * price;
  const submit = () => {
    const r = trade({ symbol, name: q?.name, side, qty, price });
    r.ok ? onDone(r.msg) : setMsg(r.msg);
  };
  return (
    <Modal onClose={onClose}>
      <h2 style={{ marginTop: 0 }}>{side === 'buy' ? '买入' : '卖出'} {symbol}</h2>
      <div className="mut small">市价单 · 模拟交易 · 现价 {fmt(price)} {q?.currency}</div>
      <input className="input" style={{ margin: '14px 0' }} type="number" inputMode="decimal" min="0" step={isCrypto ? 'any' : '1'} placeholder={isCrypto ? '数量（可小数）' : '股数'} value={qty} onChange={(e) => setQty(e.target.value)} autoFocus />
      <div className="row between small"><span className="mut">预计金额</span><b>{fmt(est)} {q?.currency}</b></div>
      <div className="row between small"><span className="mut">{side === 'buy' ? '模拟购买力 (USD)' : '可卖数量'}</span><span>{side === 'buy' ? fmt(cash) : fmt(holding?.qty, 4)}</span></div>
      {q?.currency && q.currency !== 'USD' && <div className="tiny mut" style={{ marginTop: 6 }}>注：模拟资金以 USD 计，非 USD 标的按原币种金额直接扣减，仅作演示。</div>}
      {msg && <div className="err">{msg}</div>}
      <button className={`btn full ${side === 'sell' ? 'dn' : ''}`} style={{ marginTop: 16 }} onClick={submit}>确认{side === 'buy' ? '买入' : '卖出'}</button>
      <p className="tiny mut">模拟交易不涉及真实资金与券商，价格来自 Yahoo Finance，可能有延迟。</p>
    </Modal>
  );
}
