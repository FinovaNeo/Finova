import React, { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { chat } from '../lib/api.js';
import { usePortfolio } from '../lib/portfolio.js';
import { fmt } from '../lib/utils.js';

const MODES = [
  ['财务分析师', '请以财务分析师角度，帮我梳理我的收支、预算和现金流问题。'],
  ['资产配置师', '请以资产配置师角度，为一个18-35岁零基础上班族给出分散配置思路（股票/ETF/债券/现金）。'],
  ['投资顾问', '请以投资顾问角度，教我如何研究一只股票，列出检查清单。'],
  ['AI 行动计划', '请帮我制定一份3个月的个人理财行动计划：紧急预备金、预算、开始投资。'],
];

export default function Chat() {
  const [sp] = useSearchParams();
  const symbol = sp.get('symbol') || undefined;
  const p = usePortfolio();
  const [msgs, setMsgs] = useState([{ role: 'assistant', content: '你好，我是 Finova Intelligence ✦\n可以问我理财、预算、股票、加密货币、财经新闻。选择下面的角色或直接提问。' }]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef();
  const started = useRef(false);

  const context = sp.get('ctx') || (p.rows.length ? '用户模拟持仓：' + p.rows.map((r) => `${r.sym} 市值${fmt(r.value)}`).join(', ') : '');

  const send = async (t) => {
    t = (t ?? text).trim();
    if (!t || busy) return;
    const next = [...msgs, { role: 'user', content: t }];
    setMsgs(next);
    setText('');
    setBusy(true);
    try {
      const r = await chat({ messages: next.slice(1), symbol, context });
      setMsgs([...next, { role: 'assistant', content: r.reply }]);
    } catch (e) {
      setMsgs([...next, { role: 'assistant', content: '出错了：' + e.message }]);
    }
    setBusy(false);
  };

  useEffect(() => {
    const q = sp.get('q');
    if (q && !started.current) { started.current = true; send(q); }
    // eslint-disable-next-line
  }, []);
  useEffect(() => end.current?.scrollIntoView({ behavior: 'smooth' }), [msgs, busy]);

  return (
    <div className="page" style={{ paddingBottom: 130 }}>
      <div className="row between">
        <div className="logo">Finova <b>Intelligence</b></div>
        {symbol && <span className="tag">{symbol}</span>}
      </div>
      <div className="scroll" style={{ margin: '12px 0' }}>
        {MODES.map(([n, pr]) => <button key={n} className="chip" onClick={() => send(pr)}>{n}</button>)}
      </div>
      <div className="col">
        {msgs.map((m, i) => <div key={i} className={`msg ${m.role === 'user' ? 'user' : 'bot'}`}>{m.content}</div>)}
        {busy && <div className="msg bot mut">思考中…</div>}
        <div ref={end} />
      </div>
      <div className="chatbar">
        <input className="input" placeholder="问 Finova AI…" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} />
        <button className="btn" onClick={() => send()} disabled={busy}>发送</button>
      </div>
    </div>
  );
}
