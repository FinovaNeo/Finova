import React, { useEffect, useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { LineChart, Line, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { getChart } from './lib/api.js';
import { useAsync, fmt, pct, cls, curSym } from './lib/utils.js';

export function PriceChart({ data, up = true, height = 230, onHover }) {
  if (!data) return <div className="skeleton" style={{ height }} />;
  if (!data.length) return <div className="mut small" style={{ height }}>暂无图表数据</div>;
  const color = up ? '#00c805' : '#ff5000';
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart
        data={data}
        onMouseMove={(e) => onHover && onHover(e?.activePayload?.[0]?.payload || null)}
        onMouseLeave={() => onHover && onHover(null)}
      >
        <YAxis hide domain={['auto', 'auto']} />
        <Tooltip content={() => null} cursor={{ stroke: '#666' }} />
        <Line type="monotone" dataKey="c" stroke={color} dot={false} strokeWidth={2} isAnimationActive={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function Spark({ symbol, up }) {
  const [d] = useAsync(() => getChart(symbol, '1M'), [symbol]);
  if (!d) return <div style={{ width: 70, height: 32 }} className="skeleton" />;
  const isUp = up ?? (d.length > 1 ? d[d.length - 1].c >= d[0].c : true);
  return (
    <div style={{ width: 70, height: 32 }}>
      <ResponsiveContainer>
        <LineChart data={d}>
          <YAxis hide domain={['auto', 'auto']} />
          <Line dataKey="c" dot={false} strokeWidth={1.6} stroke={isUp ? '#00c805' : '#ff5000'} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function QuoteRow({ q }) {
  const c = curSym(q.currency);
  return (
    <Link to={`/s/${encodeURIComponent(q.symbol)}`} className="li">
      <div className="grow" style={{ minWidth: 0 }}>
        <div className="sym">{q.symbol.replace('-USD', '')}</div>
        <div className="mut small" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{q.name}</div>
      </div>
      <Spark symbol={q.symbol} up={q.pct >= 0} />
      <div className="right" style={{ minWidth: 86 }}>
        <div className="bold">{c}{fmt(q.price)}</div>
        <div className={`small ${cls(q.pct)}`}>{pct(q.pct)}</div>
      </div>
    </Link>
  );
}

export function Modal({ onClose, children }) {
  return (
    <div className="modal" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>{children}</div>
    </div>
  );
}

export function Toast({ msg, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 3200);
    return () => clearTimeout(t);
  }, [msg]);
  return msg ? <div className="toast">{msg}</div> : null;
}

export function InvestTabs() {
  return (
    <div className="seg">
      {[['/invest', 'Markets'], ['/portfolio', 'Portfolio'], ['/research', 'Research']].map(([to, l]) => (
        <NavLink key={to} to={to} className={({ isActive }) => (isActive ? 'active' : '')}>{l}</NavLink>
      ))}
    </div>
  );
}

export const Err = ({ e }) => (e ? <div className="err">加载失败：{e.message}（请确认后端已启动且能访问 Yahoo Finance）</div> : null);

export function Disclaimer() {
  return (
    <p className="mut tiny" style={{ lineHeight: 1.5 }}>
      Finova Neo 仅供学习与信息参考，不构成投资建议。应用内交易为<b>模拟交易</b>，不涉及真实资金。真实证券/加密货币交易需持牌机构。
    </p>
  );
}
